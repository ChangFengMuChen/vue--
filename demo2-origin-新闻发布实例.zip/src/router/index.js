import Vue from 'vue'
import VueRouter from 'vue-router'
import Login from '../views/Login.vue'
import Home from '../views/Home.vue'
import Add from '../views/Add.vue'
Vue.use(VueRouter)

const routes = [
  {
    //如果只填写一个“/”则是表示根目录，网页第一个显示的页面
    path: '/',
    name: 'login',
    component: Login
  },
  {
    //子路由页面则要在path中写绝对路径索引才可以
    path: '/add',
    name: 'add',
    component: () => import(/* webpackChunkName: "list" */ '../views/Add.vue')
  },
  {
    path: '/home',
    name: 'home',
    component: Home,
    //配置子路由
    children:[
      {
        path:'list',
        name:'list',
        component: () => import(/* webpackChunkName: "list" */ '../views/List.vue')
      },
      {
        path:'user',
        name:'user',
        component: () => import(/* webpackChunkName: "list" */ '../views/User.vue')
      },
    ]
  },
  // {
  //   path: '/about',
  //   name: 'about',
  //   // route level code-splitting
  //   // this generates a separate chunk (about.[hash].js) for this route
  //   // which is lazy-loaded when the route is visited.
  //   component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
  // }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes,
  linkActiveClass:'active'
})

export default router
