import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    lists:[]
  },
  mutations: {
    //每次点击实现方法的时候，都会往lists数组中添加元素
    addItem(state,value){
      state.lists.push(value)
    }
  },
  actions: {
  },
  modules: {
  }
})
