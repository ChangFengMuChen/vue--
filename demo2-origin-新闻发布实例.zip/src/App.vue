<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<style lang="scss">
/*这里是全局样式*/
  *{
    padding: 0;
    margin: 0;
  }
</style>
