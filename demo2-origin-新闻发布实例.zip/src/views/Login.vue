<template>
    <div>
        <form v-if="!isReg">
            <div>用户名：</div>
            <input type="text" v-model="name">
            <div>密码：</div>
            <input type="password" v-model="password">
            <button type="button" @click="login()">登录</button>
            <button type="button" @click="reg()">注册</button>
        </form>
        <form v-else>
            <div>用户名：</div>
            <input type="text" v-model="name">
            <div>密码：</div>
            <input type="password" v-model="password">
            <div>确认密码：</div>
            <input type="password" v-model="repeat">
            <button type="button" @click="addUser()">确定</button>
            <button type="button" @click="cancel()">取消</button>
        </form>
    </div>
</template>

<script>
    export default {
        name: "Login",
        data(){
            return{
                isReg:false,
                name:'',
                password:'',
                repeat:''
            }

        },
        methods:{
            login(){
                // 验证登录
                if (localStorage.getItem('name') === this.name && localStorage.getItem('password') === this.password){
                    this.name='';
                    this.password='';
                    this.$router.push('/home/list')
                }else{
                    alert("用户名或密码不正确")
                }

            },
            reg(){
                this.isReg = true
            },
            addUser(){
                if (this.password === this.repeat){
                    //如果确认密码输入正确，则保存到 localStorage 中
                    localStorage.setItem("name",this.name);
                    localStorage.setItem("password",this.password);
                    // 保存之后把输入框清空
                    this.name='';
                    this.password=''
                    // 跳回登录界面
                    this.isReg = false
                }else{
                    alert('密码输入不一致')
                }
            },
            cancel(){
                this.isReg=false
            }
        }
    }
</script>

<style scoped>

</style>