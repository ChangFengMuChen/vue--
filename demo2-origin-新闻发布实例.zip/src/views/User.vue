<template>
    <div><p @click="reg()">添加</p></div>

</template>

<script>
    export default {
        name: "User",
        methods:{
            reg(){
                this.$router.push('/add')
            }
        }
    }
</script>

<style scoped>

</style>