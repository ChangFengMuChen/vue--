<template>
    <div>Info</div>
</template>

<script>
    export default {
        name: "Info"
    }
</script>

<style scoped>

</style>